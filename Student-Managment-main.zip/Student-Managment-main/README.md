# Student-Managment
Spring boot project with CRUD operation and more api.
